#!/usr/bin/env python3
"""
Automated self-tests for Niko. Safe to run on your Mac:
it uses a temporary folder and NEVER touches your real memory database.

Run:   python3 test_niko.py
"""
import ast
import http.server
import importlib
import json
import os
import sqlite3
import sys
import tempfile
import threading
import time
import types
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
TMP = tempfile.mkdtemp(prefix="niko_test_")
os.environ["NIKO_HOME"] = TMP          # redirect all Niko files to a temp folder
sys.path.insert(0, str(HERE))
niko = importlib.import_module("niko")

# The exact table definitions used by the ORIGINAL niko.py
ORIGINAL_DDL = [
    "CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY, content TEXT NOT NULL, created_at TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY, role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL)",
]


def make_original_db(path):
    conn = sqlite3.connect(path)
    for ddl in ORIGINAL_DDL:
        conn.execute(ddl)
    conn.executemany("INSERT INTO memories(content,created_at) VALUES(?,?)", [
        ("I prefer short explanations", "2026-01-02T10:00:00"),
        ("My name is Test \u00e9\u00e8 \u4e2d\u6587", "2026-01-03T11:30:00"),
        ("Multi\nline memory", "2026-02-01T08:00:00"),
    ])
    conn.executemany("INSERT INTO chat(role,content,created_at) VALUES(?,?,?)", [
        ("user", "hello", "2026-02-01T08:01:00"),
        ("assistant", "hi there", "2026-02-01T08:01:05"),
    ])
    conn.commit()
    conn.close()


def dump(path):
    conn = sqlite3.connect(path)
    out = {
        "memories": conn.execute("SELECT * FROM memories ORDER BY id").fetchall(),
        "chat": conn.execute("SELECT * FROM chat ORDER BY id").fetchall(),
        "schema": conn.execute("SELECT name, sql FROM sqlite_master ORDER BY name").fetchall(),
    }
    conn.close()
    return out


class FakeRun:
    """Replacement for niko.run_cmd that records commands instead of running them."""
    def __init__(self, returncode=0, stderr=""):
        self.calls, self.returncode, self.stderr = [], returncode, stderr
        self.per_app = {}

    def __call__(self, args, timeout=20):
        self.calls.append(list(args))
        rc = self.returncode
        if args[:2] == ["open", "-a"] and args[2] in self.per_app:
            rc = self.per_app[args[2]]
        return types.SimpleNamespace(returncode=rc, stdout="", stderr=self.stderr)


class Mock4891(http.server.BaseHTTPRequestHandler):
    models = [{"id": "Phi-3-mini-4k-instruct.Q4_0.gguf"}]
    chat_status = 200
    chat_body = None
    chat_delay = 0
    models_raw = None
    last_chat = None

    def log_message(self, *a):
        pass

    def _send(self, code, body):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        try:
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass  # client gave up (expected in the timeout test)

    def do_GET(self):
        if self.path.endswith("/models"):
            if Mock4891.models_raw is not None:
                return self._send(200, Mock4891.models_raw)
            return self._send(200, {"object": "list", "data": Mock4891.models})
        self._send(404, {"error": "nope"})

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length) or b"{}")
        Mock4891.last_chat = {"body": body, "auth": self.headers.get("Authorization")}
        if Mock4891.chat_delay:
            time.sleep(Mock4891.chat_delay)
        if Mock4891.chat_status != 200:
            return self._send(Mock4891.chat_status, {"error": "bad"})
        if Mock4891.chat_body is not None:
            return self._send(200, Mock4891.chat_body)
        self._send(200, {"choices": [{"message": {"role": "assistant", "content": "  Hello from Phi-3.  "}}]})


def start_server():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Mock4891)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}/v1"


def fresh_settings(**over):
    s = dict(niko.DEFAULT_SETTINGS)
    s.update(over)
    return s


class T01_Source(unittest.TestCase):
    def test_syntax_and_no_ollama(self):
        src = (HERE / "niko.py").read_text()
        ast.parse(src)
        self.assertNotIn("11434", src)
        self.assertNotIn("api/chat", src)
        self.assertNotIn("ollama_reply", src)

    def test_imports_are_standard_library_only(self):
        tree = ast.parse((HERE / "niko.py").read_text())
        top = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                top |= {a.name.split(".")[0] for a in node.names}
            elif isinstance(node, ast.ImportFrom) and node.module:
                top.add(node.module.split(".")[0])
        std = set(sys.stdlib_module_names) if hasattr(sys, "stdlib_module_names") else None
        optional = {"speech_recognition"}
        for name in top - optional:
            if std is not None:
                self.assertIn(name, std, f"non-standard import: {name}")
        self.assertIn("speech_recognition", top)  # only imported lazily inside MicRecorder
        # speech_recognition must NOT be imported at module top level
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = [a.name for a in node.names] + [getattr(node, "module", "") or ""]
                self.assertFalse(any("speech_recognition" in n for n in names))

    def test_no_send_command_in_applescript(self):
        src = (HERE / "niko.py").read_text()
        self.assertNotIn("send newMessage", src)
        self.assertNotIn("send message", src.lower().replace("send message to", ""))


class T02_Database(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(dir=TMP))
        self.db = self.dir / "niko_memory.sqlite3"
        make_original_db(self.db)
        self.before = dump(self.db)

    def test_existing_database_untouched_by_opening(self):
        m = niko.Memory(self.db)
        m.close()
        self.assertEqual(dump(self.db), self.before)  # rows AND schema identical

    def test_no_new_tables(self):
        niko.Memory(self.db).close()
        names = {r[0] for r in dump(self.db)["schema"]}
        self.assertNotIn("facts", names)
        self.assertNotIn("messages", names)
        self.assertEqual({n for n in names if not n.startswith("sqlite_")}, {"memories", "chat"})

    def test_read_old_records(self):
        m = niko.Memory(self.db)
        self.assertEqual(m.get_memories(10)[0], "I prefer short explanations")
        self.assertEqual(m.count_memories(), 3)
        self.assertEqual([c["role"] for c in m.recent_chat(10)], ["user", "assistant"])
        self.assertEqual(m.all_memories()[0][1], "2026-01-02T10:00:00")  # old timestamp preserved
        m.close()

    def test_clear_chat_keeps_memories(self):
        m = niko.Memory(self.db)
        m.clear_chat()
        self.assertEqual(m.recent_chat(10), [])
        self.assertEqual(m.count_memories(), 3)
        m.close()
        after = dump(self.db)
        self.assertEqual(after["memories"], self.before["memories"])
        self.assertEqual(after["chat"], [])

    def test_clear_chat_command_keeps_memories(self):
        m = niko.Memory(self.db)
        svc = niko.Services(m, fresh_settings())
        r = niko.handle_command("clear chat", svc)
        self.assertTrue(r.clear_display and r.no_log)
        self.assertEqual(m.count_memories(), 3)
        self.assertEqual(m.recent_chat(10), [])
        m.close()

    def test_remember_appends_only(self):
        m = niko.Memory(self.db)
        svc = niko.Services(m, fresh_settings())
        niko.handle_command("remember that I like tea", svc)
        niko.handle_command("Niko, remember I own a MacBook Air", svc)
        m.close()
        after = dump(self.db)["memories"]
        self.assertEqual(after[:3], self.before["memories"])
        self.assertEqual([r[1] for r in after[3:]], ["I like tea", "I own a MacBook Air"])

    def test_fresh_install_creates_original_schema(self):
        p = self.dir / "new.sqlite3"
        niko.Memory(p).close()
        d = dump(p)["schema"]
        self.assertEqual({n for n, _ in d if not n.startswith("sqlite_")}, {"memories", "chat"})

    def test_bad_schema_refused_without_changes(self):
        p = self.dir / "weird.sqlite3"
        c = sqlite3.connect(p)
        c.execute("CREATE TABLE memories (id INTEGER PRIMARY KEY, text TEXT)")
        c.execute("INSERT INTO memories(text) VALUES('keep me')")
        c.commit(); c.close()
        def rows():
            c = sqlite3.connect(p)
            try:
                return c.execute("SELECT * FROM memories").fetchall()
            finally:
                c.close()
        before = rows()
        with self.assertRaises(niko.SchemaError):
            niko.Memory(p)
        self.assertEqual(rows(), before)

    def test_backup_copy_is_identical_and_pruned(self):
        with mock.patch.object(niko, "BACKUP_DIR", self.dir / "Backups"):
            for i in range(13):
                niko.backup_database(self.db, keep=10)
                time.sleep(0.01)
            files = sorted((self.dir / "Backups").glob("*.sqlite3"))
            self.assertLessEqual(len(files), 10)
            self.assertGreaterEqual(len(files), 1)
            self.assertEqual(dump(files[-1])["memories"], self.before["memories"])
        self.assertEqual(dump(self.db), self.before)


class T03_Settings(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(dir=TMP))
        self.path = self.dir / "settings.json"

    def test_migration_preserves_old_keys(self):
        old = {"ollama_model": "qwen2.5:1.5b", "ollama_url": "http://localhost:11434/api/chat",
               "speak_replies": False, "window_alpha": 0.8, "voice": "Samantha", "custom_thing": [1, 2]}
        self.path.write_text(json.dumps(old))
        s, notes = niko.load_settings(self.path)
        for k, v in old.items():
            self.assertEqual(s[k], v, k)
        self.assertEqual(s["gpt4all_base_url"], "http://127.0.0.1:4891/v1")
        self.assertTrue((self.dir / "settings.json.bak-before-gpt4all").exists())
        self.assertEqual(json.loads((self.dir / "settings.json.bak-before-gpt4all").read_text()), old)
        self.assertEqual(json.loads(self.path.read_text())["ollama_model"], "qwen2.5:1.5b")

    def test_original_default_file(self):
        old = {"ollama_model": "qwen2.5:1.5b", "ollama_url": "http://localhost:11434/api/chat",
               "speak_replies": True, "window_alpha": 0.96}
        self.path.write_text(json.dumps(old, indent=2))
        s, _ = niko.load_settings(self.path)
        self.assertTrue(s["speak_replies"])
        self.assertAlmostEqual(s["window_alpha"], 0.96)

    def test_second_load_is_stable(self):
        self.path.write_text(json.dumps({"speak_replies": False}))
        s1, _ = niko.load_settings(self.path)
        text1 = self.path.read_text()
        s2, _ = niko.load_settings(self.path)
        self.assertEqual(s1, s2)
        self.assertEqual(text1, self.path.read_text())

    def test_fresh_install(self):
        s, notes = niko.load_settings(self.path)
        self.assertTrue(self.path.exists())
        self.assertNotIn("ollama_url", s)
        self.assertFalse(s["online_enabled"])
        self.assertEqual(s["online_api_key"], "")

    def test_corrupt_file_is_saved_aside(self):
        self.path.write_text("{ not json")
        s, notes = niko.load_settings(self.path)
        self.assertTrue(notes)
        self.assertTrue(list(self.dir.glob("settings.json.corrupt-*")))
        self.assertTrue(s["speak_replies"])

    def test_bad_types_are_repaired(self):
        self.path.write_text(json.dumps({"window_alpha": "abc", "speak_replies": "yes", "gpt4all_timeout_seconds": -5}))
        s, _ = niko.load_settings(self.path)
        self.assertEqual(s["window_alpha"], 0.96)
        self.assertIs(s["speak_replies"], True)
        self.assertGreaterEqual(s["gpt4all_timeout_seconds"], 10)


class T04_Commands(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(dir=TMP))
        self.mem = niko.Memory(self.dir / "m.sqlite3")
        self.svc = niko.Services(self.mem, fresh_settings())

    def tearDown(self):
        self.mem.close()

    def run_text(self, text, fake=None):
        fake = fake or FakeRun()
        with mock.patch.object(niko, "run_cmd", fake):
            return niko.handle_command(text, self.svc), fake

    def test_every_original_app_alias(self):
        original = {
            "chrome": "Google Chrome", "google chrome": "Google Chrome", "safari": "Safari", "firefox": "Firefox",
            "whatsapp": "WhatsApp", "messages": "Messages", "mail": "Mail", "apple mail": "Mail", "notes": "Notes",
            "calendar": "Calendar", "finder": "Finder", "vscode": "Visual Studio Code", "vs code": "Visual Studio Code",
            "visual studio code": "Visual Studio Code", "terminal": "Terminal", "spotify": "Spotify", "photos": "Photos"}
        for alias, app in original.items():
            self.assertEqual(niko.SAFE_APPS[alias], app)
            r, fake = self.run_text(f"open {alias}")
            self.assertEqual(fake.calls, [["open", "-a", app]], alias)
            self.assertEqual(r.text, f"Opening {app}.")
        for verb in ("launch", "start", "Please open", "niko, open"):
            r, fake = self.run_text(f"{verb} Chrome")
            self.assertEqual(fake.calls, [["open", "-a", "Google Chrome"]], verb)

    def test_every_original_site(self):
        original = {"instagram": "https://www.instagram.com", "whatsapp web": "https://web.whatsapp.com",
                    "youtube": "https://www.youtube.com", "gmail": "https://mail.google.com",
                    "google": "https://www.google.com", "github": "https://github.com", "chatgpt": "https://chatgpt.com"}
        for name, url in original.items():
            self.assertEqual(niko.SITES[name], url)
            r, fake = self.run_text(f"open {name}")
            self.assertEqual(fake.calls, [["open", url]], name)

    def test_unknown_app_refused_and_nothing_runs(self):
        r, fake = self.run_text("open rm -rf /")
        self.assertIn("approved app list", r.text)
        self.assertEqual(fake.calls, [])

    def test_start_chat_phrase_goes_to_ai(self):
        r, fake = self.run_text("start a story about dragons")
        self.assertIsNone(r)
        self.assertEqual(fake.calls, [])

    def test_whatsapp_falls_back_to_web_when_app_missing(self):
        fake = FakeRun()
        fake.per_app["WhatsApp"] = 1
        r, fake = self.run_text("open whatsapp", fake)
        self.assertEqual(fake.calls, [["open", "-a", "WhatsApp"], ["open", "https://web.whatsapp.com"]])
        self.assertIn("Web", r.text)

    def test_app_not_installed_reports_failure(self):
        r, fake = self.run_text("open spotify", FakeRun(returncode=1, stderr="Unable to find application"))
        self.assertIn("couldn't open", r.text)

    def test_google_search_is_url_encoded(self):
        r, fake = self.run_text("search for beginner network security labs & more")
        self.assertEqual(fake.calls, [["open", "https://www.google.com/search?q=beginner%20network%20security%20labs%20%26%20more"]])
        r, fake = self.run_text("search the web for cats")
        self.assertEqual(len(fake.calls), 1)
        r, fake = self.run_text("google dogs")
        self.assertIn("q=dogs", fake.calls[0][1])

    def test_memory_commands(self):
        r, _ = self.run_text("what do you remember about me")
        self.assertIn("Nothing saved yet", r.text)
        self.run_text("remember that I prefer short explanations")
        r, _ = self.run_text("What do you remember about me?")
        self.assertIn("• I prefer short explanations", r.text)
        r, _ = self.run_text("what do you know about me")
        self.assertIn("short explanations", r.text)

    def test_email_requires_confirmation_and_does_not_run_before(self):
        r, fake = self.run_text("email bob@example.com | Hi Bob | Line one\nLine \"two\"")
        self.assertIsNotNone(r.confirm)
        self.assertEqual(fake.calls, [])                       # nothing ran yet
        self.assertIn("bob@example.com", r.confirm.message)
        self.assertIn("NOT send", r.confirm.message)
        with mock.patch.object(niko, "run_cmd", fake):
            msg = r.confirm.action()                           # user clicked Yes
        self.assertEqual(len(fake.calls), 1)
        self.assertEqual(fake.calls[0][:2], ["osascript", "-e"])
        script = fake.calls[0][2]
        self.assertIn('address:"bob@example.com"', script)
        self.assertIn('content:"Line one\nLine \\"two\\""', script)
        self.assertNotIn("send ", script.lower().replace("send it yourself", ""))
        self.assertIn("press Send yourself", msg)

    def test_email_bad_address(self):
        r, fake = self.run_text("email not-an-address | s | b")
        self.assertIsNone(r.confirm)
        self.assertIn("doesn't look valid", r.text)
        self.assertEqual(fake.calls, [])

    def test_email_applescript_injection_is_escaped(self):
        r, fake = self.run_text('email a@b.co | x" & (do shell script "ls") & " | body')
        with mock.patch.object(niko, "run_cmd", fake):
            r.confirm.action()
        script = fake.calls[0][2]
        self.assertIn('\\"', script)
        self.assertNotIn('subject:"x" &', script)

    def test_email_failure_raises_helpful_error(self):
        r, _ = self.run_text("email a@b.co | s | b")
        with mock.patch.object(niko, "run_cmd", FakeRun(1, "execution error: Not authorized (-1743)")):
            with self.assertRaises(RuntimeError) as cm:
                r.confirm.action()
        self.assertIn("Automation", str(cm.exception))

    def test_normal_chat_is_not_a_command(self):
        for t in ("how are you?", "what is the capital of France", "tell me a joke"):
            r, _ = self.run_text(t)
            self.assertIsNone(r, t)

    def test_help_and_online_not_configured(self):
        r, _ = self.run_text("help")
        self.assertIn("clear chat", r.text)
        r, fake = self.run_text("ask online: what is quantum computing")
        self.assertTrue(r.is_error)
        self.assertIn("isn't set up", r.text)
        self.assertEqual(fake.calls, [])


class T05_Gpt4All(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv, cls.base = start_server()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        Mock4891.models = [{"id": "Phi-3-mini-4k-instruct.Q4_0.gguf"}]
        Mock4891.chat_status, Mock4891.chat_body, Mock4891.chat_delay, Mock4891.models_raw = 200, None, 0, None

    def client(self, **over):
        return niko.Gpt4AllClient(fresh_settings(gpt4all_base_url=self.base, **over))

    def test_discovers_model_from_models_endpoint(self):
        c = self.client()
        self.assertEqual(c.ensure_model(), "Phi-3-mini-4k-instruct.Q4_0.gguf")

    def test_prefers_phi_among_several(self):
        Mock4891.models = [{"id": "Llama-3"}, {"id": "Niko-Phi-3"}, {"id": "Other"}]
        self.assertEqual(self.client().ensure_model(), "Niko-Phi-3")

    def test_configured_model_used_and_missing_reported(self):
        Mock4891.models = [{"id": "Niko"}, {"id": "Phi-3"}]
        self.assertEqual(self.client(gpt4all_model="niko").ensure_model(), "Niko")
        with self.assertRaises(niko.AIError) as cm:
            self.client(gpt4all_model="Nope").ensure_model()
        self.assertIn("Niko, Phi-3", str(cm.exception))

    def test_chat_success_sends_discovered_model(self):
        reply = self.client().chat([{"role": "user", "content": "hi"}])
        self.assertEqual(reply, "Hello from Phi-3.")
        sent = Mock4891.last_chat["body"]
        self.assertEqual(sent["model"], "Phi-3-mini-4k-instruct.Q4_0.gguf")
        self.assertIs(sent["stream"], False)
        self.assertIn("max_tokens", sent)

    def test_no_models(self):
        Mock4891.models = []
        with self.assertRaises(niko.AIError) as cm:
            self.client().ensure_model()
        self.assertIn("no models", str(cm.exception))

    def test_server_offline(self):
        c = niko.Gpt4AllClient(fresh_settings(gpt4all_base_url="http://127.0.0.1:9/v1"))
        for call in (c.check, lambda: c.chat([{"role": "user", "content": "x"}])):
            with self.assertRaises(niko.AIError) as cm:
                call()
            self.assertIn("Enable Local API Server", str(cm.exception))

    def test_timeout(self):
        Mock4891.chat_delay = 3
        c = self.client()
        c.s["gpt4all_timeout_seconds"] = 1
        c._model = "x"
        # _coerce_settings enforces >=10 on load; here we call the client directly with 1s
        with self.assertRaises(niko.AIError) as cm:
            c.chat([{"role": "user", "content": "x"}])
        self.assertIn("didn't finish", str(cm.exception))

    def test_http_500(self):
        Mock4891.chat_status = 500
        with self.assertRaises(niko.AIError) as cm:
            self.client().chat([{"role": "user", "content": "x"}])
        self.assertIn("500", str(cm.exception))

    def test_stale_model_rediscovered_once_on_404(self):
        c = self.client()
        c._model = "old-model"
        calls = {"n": 0}
        real = niko._http_json

        def flaky(url, payload=None, **kw):
            if url.endswith("/chat/completions"):
                calls["n"] += 1
                if payload["model"] == "old-model":
                    raise niko._HttpFail("http", "no such model", 404)
            return real(url, payload, **kw)
        with mock.patch.object(niko, "_http_json", flaky):
            self.assertEqual(c.chat([{"role": "user", "content": "x"}]), "Hello from Phi-3.")
        self.assertEqual(calls["n"], 2)

    def test_empty_and_malformed_replies(self):
        Mock4891.chat_body = {"choices": [{"message": {"content": "   "}}]}
        with self.assertRaises(niko.AIError):
            self.client().chat([{"role": "user", "content": "x"}])
        Mock4891.chat_body = {"unexpected": True}
        with self.assertRaises(niko.AIError):
            self.client().chat([{"role": "user", "content": "x"}])

    def test_non_json_models_reply(self):
        Mock4891.models_raw = b"<html>not gpt4all</html>"
        with self.assertRaises(niko.AIError) as cm:
            self.client().ensure_model()
        self.assertIn("doesn't look like GPT4All", str(cm.exception))

    def test_check_command(self):
        mem = niko.Memory(Path(tempfile.mkdtemp(dir=TMP)) / "m.sqlite3")
        svc = niko.Services(mem, fresh_settings(gpt4all_base_url=self.base))
        r = niko.handle_command("check ai", svc)
        self.assertIn("Using model: Phi-3", r.text)
        self.assertEqual(r.ai_status, "AI: ready")
        mem.close()


class T06_Online(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv, cls.base = start_server()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_needs_all_of_enabled_key_model(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("NIKO_ONLINE_API_KEY", None)
            self.assertFalse(niko.OnlineProvider(fresh_settings()).configured())
            self.assertFalse(niko.OnlineProvider(fresh_settings(online_enabled=True, online_model="m")).configured())
            self.assertFalse(niko.OnlineProvider(fresh_settings(online_enabled=True, online_api_key="k")).configured())
            self.assertTrue(niko.OnlineProvider(fresh_settings(online_enabled=True, online_api_key="k", online_model="m")).configured())

    def test_env_var_key_and_no_memory_sent(self):
        Mock4891.chat_status, Mock4891.chat_body = 200, None
        s = fresh_settings(online_enabled=True, online_model="m", online_base_url=self.base)
        with mock.patch.dict(os.environ, {"NIKO_ONLINE_API_KEY": "test-key"}):
            p = niko.OnlineProvider(s)
            self.assertEqual(p.chat("hard question"), "Hello from Phi-3.")
        self.assertEqual(Mock4891.last_chat["auth"], "Bearer test-key")
        msgs = Mock4891.last_chat["body"]["messages"]
        self.assertEqual([m["role"] for m in msgs], ["system", "user"])
        self.assertEqual(msgs[1]["content"], "hard question")

    def test_online_command_requires_confirmation(self):
        mem = niko.Memory(Path(tempfile.mkdtemp(dir=TMP)) / "m.sqlite3")
        s = fresh_settings(online_enabled=True, online_model="m", online_api_key="k", online_base_url=self.base)
        svc = niko.Services(mem, s)
        r = niko.handle_command("ask online: explain entropy", svc)
        self.assertIsNotNone(r.confirm)
        self.assertIn("NOT sent", r.confirm.message)
        mem.close()

    def test_rejected_key(self):
        Mock4891.chat_status = 401
        s = fresh_settings(online_enabled=True, online_model="m", online_api_key="bad", online_base_url=self.base)
        with self.assertRaises(niko.AIError) as cm:
            niko.OnlineProvider(s).chat("x")
        self.assertIn("rejected your API key", str(cm.exception))
        Mock4891.chat_status = 200


class T07_Prompt(unittest.TestCase):
    def test_history_alternates_and_no_duplicate_user_message(self):
        hist = [{"role": "assistant", "content": "orphan"}, {"role": "user", "content": "a"},
                {"role": "user", "content": "b"}, {"role": "assistant", "content": "c"},
                {"role": "user", "content": "just saved current message"}]
        out = niko.normalize_history(hist)
        self.assertEqual([m["role"] for m in out], ["user", "assistant"])
        self.assertEqual(out[0]["content"], "a\nb")

    def test_build_messages(self):
        mem = niko.Memory(Path(tempfile.mkdtemp(dir=TMP)) / "m.sqlite3")
        mem.remember("I like tea")
        mem.save_chat("user", "hi"); mem.save_chat("assistant", "hello")
        msgs = niko.build_messages(mem, fresh_settings(), "what now?")
        self.assertEqual(msgs[0]["role"], "system")
        self.assertIn("I like tea", msgs[0]["content"])
        self.assertEqual([m["role"] for m in msgs[1:]], ["user", "assistant", "user"])
        self.assertEqual(msgs[-1]["content"], "what now?")
        mem.close()


class T08_Voice(unittest.TestCase):
    def test_say_command_and_interrupt(self):
        procs = []

        class FakeProc:
            def __init__(self, args, **kw):
                self.args, self.terminated, self.written = args, False, b""
                self.stdin = types.SimpleNamespace(write=lambda b: setattr(self, "written", b), close=lambda: None)
                procs.append(self)

            def poll(self):
                return None

            def terminate(self):
                self.terminated = True

        sp = niko.Speaker(fresh_settings(voice="Samantha"))
        with mock.patch.object(niko.subprocess, "Popen", FakeProc):
            sp._run(sp.clean("hello https://example.com/x -rf"))
            sp._run("second")
        self.assertEqual(procs[0].args, ["say", "-v", "Samantha", "-f", "-"])
        self.assertIn(b"hello link -rf", procs[0].written)   # URL replaced, text sent via stdin
        self.assertTrue(procs[0].terminated)                 # first speech interrupted by second
        sp.stop()
        self.assertTrue(procs[1].terminated)

    def test_bad_voice_name_ignored(self):
        procs = []

        class FakeProc:
            def __init__(self, args, **kw):
                self.args = args; procs.append(self)
                self.stdin = types.SimpleNamespace(write=lambda b: None, close=lambda: None)

            def poll(self): return None
            def terminate(self): pass
        with mock.patch.object(niko.subprocess, "Popen", FakeProc):
            niko.Speaker(fresh_settings(voice="-evil; rm"))._run("x")
        self.assertEqual(procs[0].args, ["say", "-f", "-"])

    def test_say_missing_does_not_crash(self):
        with mock.patch.object(niko.subprocess, "Popen", side_effect=FileNotFoundError):
            niko.Speaker(fresh_settings())._run("x")


class T09_Microphone(unittest.TestCase):
    def fake_sr(self, mic_error=None, recognize=None):
        sr = types.ModuleType("speech_recognition")

        class UnknownValueError(Exception): pass
        class RequestError(Exception): pass

        class Stream:
            def read(self, n): return b"\x00\x01" * 10

        class Mic:
            CHUNK, SAMPLE_RATE, SAMPLE_WIDTH = 1024, 16000, 2

            def __init__(self):
                if mic_error: raise mic_error
                self.stream = Stream()

            def __enter__(self): return self
            def __exit__(self, *a): return False

        class Recognizer:
            def recognize_google(self, audio, language="en-US"):
                if isinstance(recognize, Exception): raise recognize
                return recognize or " open chrome "

        sr.Microphone, sr.Recognizer = Mic, Recognizer
        sr.AudioData = lambda data, rate, width: ("audio", len(data), rate, width)
        sr.UnknownValueError, sr.RequestError = UnknownValueError, RequestError
        return sr

    def record(self, sr, stop_after=0.05):
        rec = niko.MicRecorder()
        threading.Timer(stop_after, rec.stop).start()
        with mock.patch.dict(sys.modules, {"speech_recognition": sr}):
            return rec.record_and_transcribe("en-US")

    def test_success_strips_text(self):
        self.assertEqual(self.record(self.fake_sr()), "open chrome")

    def test_not_installed(self):
        with mock.patch.dict(sys.modules, {"speech_recognition": None}):
            with self.assertRaises(niko.MicError) as cm:
                niko.MicRecorder().record_and_transcribe()
        self.assertIn("requirements-microphone.txt", str(cm.exception))

    def test_pyaudio_missing(self):
        with self.assertRaises(niko.MicError) as cm:
            self.record(self.fake_sr(mic_error=AttributeError("Could not find PyAudio")))
        self.assertIn("PyAudio", str(cm.exception))

    def test_no_microphone(self):
        with self.assertRaises(niko.MicError) as cm:
            self.record(self.fake_sr(mic_error=OSError("no device")))
        self.assertIn("No microphone", str(cm.exception))

    def test_unrecognised_and_offline(self):
        sr = self.fake_sr()
        sr2 = self.fake_sr(recognize=sr.UnknownValueError())
        # recognize raises the class belonging to its own fake module
        sr2.Recognizer.recognize_google = lambda self, a, language="en-US": (_ for _ in ()).throw(sr2.UnknownValueError())
        with self.assertRaises(niko.MicError) as cm:
            self.record(sr2)
        self.assertIn("couldn't understand", str(cm.exception))
        sr3 = self.fake_sr()
        sr3.Recognizer.recognize_google = lambda self, a, language="en-US": (_ for _ in ()).throw(sr3.RequestError("no internet"))
        with self.assertRaises(niko.MicError) as cm:
            self.record(sr3)
        self.assertIn("internet", str(cm.exception))

    def test_privacy_notice_is_honest(self):
        self.assertIn("SENT TO GOOGLE", niko.MIC_PRIVACY_NOTICE)
        self.assertIn("NOT offline", niko.MIC_PRIVACY_NOTICE)


class T10_GuiLogicWithMockTk(unittest.TestCase):
    """
    Runs the window code against a fake Tkinter. This catches typos and logic
    errors, but it is NOT a real window. A real-window check needs your Mac.
    """

    def setUp(self):
        self.tkmock = mock.MagicMock()
        self.tkmock.TkVersion = 8.6
        self.mb = mock.MagicMock()
        self.patches = [mock.patch.object(niko, "tk", self.tkmock), mock.patch.object(niko, "messagebox", self.mb)]
        for p in self.patches: p.start()
        self.dir = Path(tempfile.mkdtemp(dir=TMP))
        self.mem = niko.Memory(self.dir / "m.sqlite3")
        self.settings = fresh_settings()
        self.svc = niko.Services(self.mem, self.settings)
        self.root = mock.MagicMock()
        with mock.patch.object(niko, "save_settings"), mock.patch.object(niko.NikoApp, "startup_check"):
            self.app = niko.NikoApp(self.root, self.svc)
        self.app.speaker = mock.MagicMock()
        self.app.entry.get.return_value = ""

    def tearDown(self):
        for p in self.patches: p.stop()
        self.mem.close()

    def drain(self, timeout=3.0):
        end = time.time() + timeout
        while time.time() < end:
            try:
                fn, args = self.app.ui_queue.get(timeout=0.05)
            except Exception:
                if not self.app.busy:
                    return
                continue
            fn(*args)
            if not self.app.busy and self.app.ui_queue.empty():
                return

    def type_and_send(self, text):
        self.app.entry.get.return_value = text
        self.app.send()
        self.drain()

    def test_chat_flow_saves_history_once_and_speaks(self):
        with mock.patch.object(niko, "local_ai_reply", return_value="Hi, I'm Niko."):
            self.type_and_send("hello niko")
        hist = self.mem.recent_chat(10)
        self.assertEqual([(h["role"], h["content"]) for h in hist], [("user", "hello niko"), ("assistant", "Hi, I'm Niko.")])
        self.assertFalse(self.app.busy)
        self.app.speaker.speak.assert_called_with("Hi, I'm Niko.")

    def test_error_not_saved_or_spoken(self):
        with mock.patch.object(niko, "local_ai_reply", side_effect=niko.AIError("server offline")):
            self.type_and_send("hello")
        self.assertEqual(self.mem.recent_chat(10), [])
        self.app.speaker.speak.assert_not_called()
        self.assertFalse(self.app.busy)

    def test_duplicate_send_ignored_while_busy(self):
        gate = threading.Event()
        calls = []

        def slow(svc, text):
            calls.append(text); gate.wait(2); return "done"
        with mock.patch.object(niko, "local_ai_reply", slow):
            self.app.entry.get.return_value = "one"
            self.app.send()
            self.app.entry.get.return_value = "two"
            self.app.send()           # ignored: still busy
            time.sleep(0.2)
            gate.set()
            self.drain()
        self.assertEqual(calls, ["one"])

    def test_dialog_only_on_main_thread_and_decline_creates_nothing(self):
        main = threading.get_ident()
        seen = []
        self.mb.askyesno.side_effect = lambda *a, **k: (seen.append(threading.get_ident()), False)[1]
        fake = FakeRun()
        with mock.patch.object(niko, "run_cmd", fake):
            self.type_and_send("email a@b.co | Subject | Body")
        self.assertEqual(seen, [main])
        self.assertEqual(fake.calls, [])
        self.assertFalse(self.app.busy)

    def test_email_accept_runs_osascript_once(self):
        self.mb.askyesno.return_value = True
        fake = FakeRun()
        with mock.patch.object(niko, "run_cmd", fake):
            self.type_and_send("email a@b.co | Subject | Body")
        self.assertEqual([c[0] for c in fake.calls], ["osascript"])
        self.assertFalse(self.app.busy)

    def test_clear_chat_through_window_keeps_memories(self):
        self.mem.remember("keep me")
        self.mem.save_chat("user", "old")
        self.type_and_send("clear chat")
        self.assertEqual(self.mem.recent_chat(10), [])
        self.assertEqual(self.mem.get_memories(), ["keep me"])

    def test_mic_flow_inserts_text_and_acknowledges_privacy_first(self):
        self.mb.askokcancel.return_value = True
        recorded = threading.Event()
        with mock.patch.object(niko, "save_settings"):
            with mock.patch.object(self.app.recorder, "record_and_transcribe", return_value="open chrome"):
                self.app.toggle_mic()
                self.assertEqual(self.app.mic_state, "listening")
                self.mb.askokcancel.assert_called_once()
                end = time.time() + 2
                while time.time() < end and self.app.mic_state != "idle":
                    try:
                        fn, args = self.app.ui_queue.get(timeout=0.05); fn(*args)
                    except Exception:
                        pass
        self.assertEqual(self.app.mic_state, "idle")
        self.app.entry.insert.assert_called_with(0, "open chrome")

    def test_mic_declined_privacy_does_not_record(self):
        self.mb.askokcancel.return_value = False
        with mock.patch.object(self.app.recorder, "record_and_transcribe") as rec:
            self.app.toggle_mic()
        rec.assert_not_called()
        self.assertEqual(self.app.mic_state, "idle")

    def test_close_stops_things(self):
        self.app.on_close()
        self.assertTrue(self.app.closing)
        self.root.destroy.assert_called_once()
        self.app.speaker.stop.assert_called()

    def test_worker_functions_never_touch_widgets(self):
        """Static check: functions that run in background threads must not use widgets or dialogs."""
        tree = ast.parse((HERE / "niko.py").read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "NikoApp")
        workers = {"process", "run_confirmed", "mic_worker", "startup_check"}
        banned_attrs = {"chat", "entry", "status", "ai_label", "mic_btn", "voice_btn", "send_btn", "root"}
        found = set()
        for fn in cls.body:
            if isinstance(fn, ast.FunctionDef) and fn.name in workers:
                found.add(fn.name)
                for node in ast.walk(fn):
                    if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "self":
                        self.assertNotIn(node.attr, banned_attrs, f"{fn.name} touches self.{node.attr}")
                    if isinstance(node, ast.Name):
                        self.assertNotIn(node.id, {"messagebox", "tk"}, f"{fn.name} uses {node.id}")
        self.assertEqual(found, workers)


if __name__ == "__main__":
    unittest.main(verbosity=2)
