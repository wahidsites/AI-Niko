#!/bin/bash
# Double-click to start Niko. (First time: right-click > Open.)
cd "$(dirname "$0")" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 was not found."
  echo "Install it from https://www.python.org/downloads/macos/ and try again."
  read -r -p "Press Return to close." _
  exit 1
fi

if ! python3 -c "import tkinter" >/dev/null 2>&1; then
  echo "This Python has no Tkinter (the window toolkit)."
  echo "Install Python from https://www.python.org/downloads/macos/ (it includes Tkinter) and try again."
  read -r -p "Press Return to close." _
  exit 1
fi

python3 niko.py
status=$?
if [ $status -ne 0 ]; then
  echo
  echo "Niko stopped with an error (code $status). Please read the message above."
  read -r -p "Press Return to close." _
fi
